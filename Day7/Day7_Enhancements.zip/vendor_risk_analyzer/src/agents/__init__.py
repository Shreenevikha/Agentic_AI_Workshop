"""
Agents package for vendor risk analysis
""" 