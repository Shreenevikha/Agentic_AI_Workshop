"""
Agent modules for vendor risk analysis.
""" 