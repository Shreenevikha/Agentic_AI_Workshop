"""
Vendor Risk Analyzer package
""" 