"""
Vendor Risk Analyzer - An AI-powered system for evaluating vendor credibility and compliance risk.
"""

__version__ = "0.1.0" 