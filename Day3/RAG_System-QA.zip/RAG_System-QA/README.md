1.Give your gemini ai or open ai token in .env file

2.install this libraries --> pip install --user chromadb PyMuPDF google-generativeai python-dotenv tqdm sentence-transformers

 Add the Required PDF Files in the Pdf_files -->folder
